# Share

A self-hosted artifact host. An agent posts finished files over an API and gets
back a stable URL. You keep the artifacts and hand them out with links that
expire.

Runs on your own machine, your own Postgres, your own disk.

## What it does

```
$ share post ./build --title "Q3 margin review"
Posting build  (14 files)

https://share.c52.com/robert/q3-margin-review/
```

The same thing over MCP, which is the point — an agent that can call tools can
publish its own output:

```json
{
  "name": "share_post",
  "arguments": {
    "title": "Q3 margin review",
    "files": [
      { "path": "index.html", "content": "<!DOCTYPE html>...",
        "contentType": "text/html; charset=utf-8" }
    ]
  }
}
```

Six tools at `POST /mcp`, bearer token:

| Tool | Does |
| --- | --- |
| `share_post` | Post files as an artifact. Returns the URL. |
| `share_list` | List artifacts in the caller's space. |
| `share_get` | Get one artifact by name. |
| `share_delete` | Move an artifact to trash. |
| `share_restore` | Restore an artifact from trash. |
| `share_whoami` | Return the authenticated identity. |

## Properties

- **Private by default.** A posted artifact is visible to its owner. There is no
  "anyone with the link" state you can reach by accident.
- **Links expire.** Created with a TTL, an optional label and an optional
  password. Revoking one stops it resolving immediately.
- **Unknown and unauthorized are the same 404.** Authorization has four cases and
  no fifth; probing an artifact you may not see tells you nothing.
- **Content-addressed.** Files are stored by SHA-256, so re-posting a directory
  uploads only what changed.
- **Versioned.** Posting again under the same name makes a new version. Nothing
  is overwritten; earlier versions stay addressable.
- **Headers on.** Artifact responses carry a CSP, `nosniff`, `noindex` and a
  strict referrer policy.
- **Secrets guard.** `share post` refuses files that look like secrets unless you
  pass `--force-secrets`.

## Install

Python 3.13, PostgreSQL, Redis.

```bash
git clone https://github.com/iXanadu/ShareWeb.git
cd ShareWeb

pyenv virtualenv 3.13.12 share-3.13
pyenv local share-3.13
pip install -e ".[dev]"

cp examples/.env.example .env
cp examples/.keys.example .keys && chmod 600 .keys
# fill SHARE_SECRET_KEY and SHARE_VIEW_SALT

sharectl bootstrap --email you@example.com --handle you
uvicorn server.main:app --reload --port 8000
```

Then sign in with a passkey at `/~`, issue a token under Tokens, and point the
CLI or an agent at it.

```bash
share login          # device code; approve it in the dashboard
share post ./build
```

Caddy in front is optional — the API serves artifact bytes if Caddy is absent.

## Status

Phase 1 is built and tested: identity, artifacts, versions, trash, tokens,
serving, expiring links. Phase 2 (broader sharing), Phase 3 (multiple users) and
Phase 4 (hardening) are specified but not built.

Deferred work lives in one file: [BACKLOG.md](BACKLOG.md). If it is not there, it
is not tracked.

## Docs

Share was specified before it was built, and the spec is the source of truth for
behaviour.

- [docs/specs/spec/START-HERE.md](docs/specs/spec/START-HERE.md) — what to read, in order
- [01-overview.md](docs/specs/spec/01-overview.md) — what the product is and is not
- [09-agent-surface.md](docs/specs/spec/09-agent-surface.md) — MCP and the CLI
- [DECISIONS.md](docs/specs/spec/DECISIONS.md) — where ambiguity got settled
- [AGENTS.md](AGENTS.md) — setup, commands, conventions

## Stack

FastAPI on Python 3.13, PostgreSQL over asyncpg, Redis for cache and rate limits,
structlog, pytest-asyncio, ruff.

```bash
pytest tests/ -v
ruff check .
```

## License

See [LICENSE](LICENSE).
